namespace calculator
{
    public enum ArithmeticOperationType
    {
        Add,
        subract,
        Multiply,
        Divide,
        log,
        sin,
        cos,
        tan,
        percentage,
        square,
        squareroot,
        exponential,
        pi
    }
    public partial class Form1 : Form
    {
        decimal resultnumber = 0;
        decimal previousnumber = 0;
        double m1;
        ArithmeticOperationType currentOperationType;
        private decimal previousNumber;

        public Form1()
        {
            InitializeComponent();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            currentOperationType = ArithmeticOperationType.percentage;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btnrgtbrckt.Text);
        }
        //sruare root
        private void button6_Click(object sender, EventArgs e)
        {
            currentOperationType = ArithmeticOperationType.squareroot;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btnfour.Text);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btnfive.Text);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            currentOperationType = ArithmeticOperationType.pi;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            currentOperationType = ArithmeticOperationType.log;
        }
        //SQUARE
        private void button7_Click(object sender, EventArgs e)
        {
            //previousnumber = Convert.ToDecimal(textresult.Text);
            //textresult.Text = string.Empty;
            currentOperationType = ArithmeticOperationType.square;
        }
        private void button11_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btnseven.Text);
        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            textresult.Clear();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btnsix.Text);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            previousNumber = Convert.ToDecimal(textresult.Text);
            textresult.Text = string.Empty;

            currentOperationType = ArithmeticOperationType.Multiply;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            previousNumber = Convert.ToDecimal(textresult.Text);
            textresult.Text = string.Empty;

            currentOperationType = ArithmeticOperationType.Divide;
        }

        private void button28_Click(object sender, EventArgs e)
        {
            currentOperationType = ArithmeticOperationType.exponential;
        }
        //tan
        private void btntan_Click(object sender, EventArgs e)
        {
            currentOperationType = ArithmeticOperationType.tan;
        }
        //SIN
        private void btnsin_Click(object sender, EventArgs e)
        {
            currentOperationType = ArithmeticOperationType.sin;
            //textresult.Text = string.Concat(textresult.Text);
        }

        private void btnone_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btnone.Text);
        }

        private void btnthree_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btnthree.Text);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btneight_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btneight.Text);
        }

        private void btnnine_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btnnine.Text);
        }

        private void btntwo_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btntwo.Text);
        }

        private void btnzero_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btnzero.Text);
        }

        private void btndot_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btndot.Text);
        }

        private void btnleftbrckt_Click(object sender, EventArgs e)
        {
            textresult.Text = string.Concat(textresult.Text, btnleftbrckt.Text);
        }
        private void btnminus_Click(object sender, EventArgs e)
        {
            previousNumber = Convert.ToDecimal(textresult.Text);
            textresult.Text = string.Empty;

            currentOperationType = ArithmeticOperationType.subract;
        }
        private void btnplus_Click(object sender, EventArgs e)
        {
            previousNumber = Convert.ToDecimal(textresult.Text);
            textresult.Text = string.Empty;

            currentOperationType = ArithmeticOperationType.Add;
        }

        private void btncos_Click(object sender, EventArgs e)
        {
            currentOperationType = ArithmeticOperationType.cos;
        }

        private void btnequal_Click(object sender, EventArgs e)
        {
            switch (currentOperationType)
            {
                case ArithmeticOperationType.Add:
                    {
                        textresult.Text = Convert.ToString(previousNumber + Convert.ToDecimal(textresult.Text));
                        break;
                    }
                case ArithmeticOperationType.subract:
                    {
                        textresult.Text = Convert.ToString(previousNumber - Convert.ToDecimal(textresult.Text));
                        break;
                    }
                case ArithmeticOperationType.Multiply:
                    {
                        textresult.Text = Convert.ToString(previousNumber * Convert.ToDecimal(textresult.Text));
                        break;
                    }
                case ArithmeticOperationType.Divide:
                    {
                        textresult.Text = Convert.ToString(previousNumber / Convert.ToDecimal(textresult.Text));
                        break;
                    }
                case ArithmeticOperationType.square:
                    {
                        m1 = double.Parse(textresult.Text);
                        m1 = Math.Pow(m1, 2);
                        textresult.Text = m1.ToString();
                        //textresult.Text = Convert.ToString(Math.Pow(previousnumber,2));
                        //previousnumber = Convert.ToDecimal(Math.Pow(previousnumber, 2));

                        break;
                    }
                case ArithmeticOperationType.sin:
                    {
                        m1 = double.Parse(textresult.Text);
                        m1 = Math.Sin(m1);
                        textresult.Text = m1.ToString();
                        break;
                    }
                case ArithmeticOperationType.cos:
                    {
                        m1 = double.Parse(textresult.Text);
                        m1 = Math.Cos(m1);
                        textresult.Text = m1.ToString();
                        break;
                    }
                case ArithmeticOperationType.tan:
                    {
                        m1 = double.Parse(textresult.Text);
                        m1 = Math.Tan(m1);
                        textresult.Text = m1.ToString();
                        break;
                    }
                case ArithmeticOperationType.log:
                    {
                        m1 = double.Parse(textresult.Text);
                        m1 = Math.Log10(m1);
                        textresult.Text = m1.ToString();
                        break;
                    }
                case ArithmeticOperationType.squareroot:
                    {
                        m1 = double.Parse(textresult.Text);
                        m1 = Math.Sqrt(m1);
                        textresult.Text = m1.ToString();
                        break;
                    }
                case ArithmeticOperationType.percentage:
                    {
                        m1 = double.Parse(textresult.Text);
                        m1 = m1 / 100;
                        textresult.Text = m1.ToString();
                        break;
                    }
                case ArithmeticOperationType.exponential:
                    {
                        m1 = double.Parse(textresult.Text);
                        m1 = Math.Exp(m1);
                        textresult.Text = m1.ToString();
                        break;
                    }
                case ArithmeticOperationType.pi:
                    {
                        m1 = Math.PI;
                        textresult.Text = m1.ToString();
                        break;
                    }


            }

        }



       

      
    }
}