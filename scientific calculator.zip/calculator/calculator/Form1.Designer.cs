﻿namespace calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnsin = new Button();
            textresult = new TextBox();
            btncos = new Button();
            btntan = new Button();
            btnin = new Button();
            btnlog = new Button();
            btnshift = new Button();
            btnsquare = new Button();
            btnpercentage = new Button();
            btnrgtbrckt = new Button();
            btnleftbrckt = new Button();
            btnseven = new Button();
            btneight = new Button();
            btnnine = new Button();
            btnclear = new Button();
            btnactclr = new Button();
            btnfour = new Button();
            btnfive = new Button();
            btnsix = new Button();
            btndivide = new Button();
            btnone = new Button();
            btntwo = new Button();
            btnthree = new Button();
            btnplus = new Button();
            btnminus = new Button();
            btnzero = new Button();
            btndot = new Button();
            btnexp = new Button();
            btnans = new Button();
            btnequal = new Button();
            btnmulty = new Button();
            SuspendLayout();
            // 
            // btnsin
            // 
            btnsin.Location = new Point(47, 92);
            btnsin.Name = "btnsin";
            btnsin.Size = new Size(67, 52);
            btnsin.TabIndex = 0;
            btnsin.Text = "sin";
            btnsin.UseVisualStyleBackColor = true;
            btnsin.Click += btnsin_Click;
            // 
            // textresult
            // 
            textresult.BackColor = SystemColors.ControlLightLight;
            textresult.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            textresult.Location = new Point(47, 23);
            textresult.Multiline = true;
            textresult.Name = "textresult";
            textresult.Size = new Size(447, 50);
            textresult.TabIndex = 1;
            textresult.TextAlign = HorizontalAlignment.Right;
            textresult.TextChanged += textBox1_TextChanged;
            // 
            // btncos
            // 
            btncos.Location = new Point(144, 92);
            btncos.Name = "btncos";
            btncos.Size = new Size(67, 52);
            btncos.TabIndex = 2;
            btncos.Text = "cos";
            btncos.UseVisualStyleBackColor = true;
            btncos.Click += btncos_Click;
            // 
            // btntan
            // 
            btntan.Location = new Point(243, 92);
            btntan.Name = "btntan";
            btntan.Size = new Size(67, 52);
            btntan.TabIndex = 3;
            btntan.Text = "tan";
            btntan.UseVisualStyleBackColor = true;
            btntan.Click += btntan_Click;
            // 
            // btnin
            // 
            btnin.Location = new Point(339, 92);
            btnin.Name = "btnin";
            btnin.Size = new Size(67, 52);
            btnin.TabIndex = 4;
            btnin.Text = "pi";
            btnin.UseVisualStyleBackColor = true;
            btnin.Click += button4_Click;
            // 
            // btnlog
            // 
            btnlog.Location = new Point(427, 92);
            btnlog.Name = "btnlog";
            btnlog.Size = new Size(67, 52);
            btnlog.TabIndex = 5;
            btnlog.Text = "log";
            btnlog.UseVisualStyleBackColor = true;
            btnlog.Click += button5_Click;
            // 
            // btnshift
            // 
            btnshift.Location = new Point(47, 167);
            btnshift.Name = "btnshift";
            btnshift.Size = new Size(67, 52);
            btnshift.TabIndex = 6;
            btnshift.Text = "sqrt";
            btnshift.UseVisualStyleBackColor = true;
            btnshift.Click += button6_Click;
            // 
            // btnsquare
            // 
            btnsquare.Location = new Point(144, 167);
            btnsquare.Name = "btnsquare";
            btnsquare.Size = new Size(67, 52);
            btnsquare.TabIndex = 7;
            btnsquare.Text = "^";
            btnsquare.UseVisualStyleBackColor = true;
            btnsquare.Click += button7_Click;
            // 
            // btnpercentage
            // 
            btnpercentage.Location = new Point(243, 167);
            btnpercentage.Name = "btnpercentage";
            btnpercentage.Size = new Size(67, 52);
            btnpercentage.TabIndex = 8;
            btnpercentage.Text = "%";
            btnpercentage.UseVisualStyleBackColor = true;
            btnpercentage.Click += button8_Click;
            // 
            // btnrgtbrckt
            // 
            btnrgtbrckt.Location = new Point(339, 167);
            btnrgtbrckt.Name = "btnrgtbrckt";
            btnrgtbrckt.Size = new Size(67, 52);
            btnrgtbrckt.TabIndex = 9;
            btnrgtbrckt.Text = "(";
            btnrgtbrckt.UseVisualStyleBackColor = true;
            btnrgtbrckt.Click += button9_Click;
            // 
            // btnleftbrckt
            // 
            btnleftbrckt.Location = new Point(427, 167);
            btnleftbrckt.Name = "btnleftbrckt";
            btnleftbrckt.Size = new Size(67, 52);
            btnleftbrckt.TabIndex = 10;
            btnleftbrckt.Text = ")";
            btnleftbrckt.UseVisualStyleBackColor = true;
            btnleftbrckt.Click += btnleftbrckt_Click;
            // 
            // btnseven
            // 
            btnseven.Location = new Point(47, 235);
            btnseven.Name = "btnseven";
            btnseven.Size = new Size(67, 52);
            btnseven.TabIndex = 11;
            btnseven.Text = "7";
            btnseven.UseVisualStyleBackColor = true;
            btnseven.Click += button11_Click;
            // 
            // btneight
            // 
            btneight.Location = new Point(144, 233);
            btneight.Name = "btneight";
            btneight.Size = new Size(67, 52);
            btneight.TabIndex = 12;
            btneight.Text = "8";
            btneight.UseVisualStyleBackColor = true;
            btneight.Click += btneight_Click;
            // 
            // btnnine
            // 
            btnnine.Location = new Point(243, 233);
            btnnine.Name = "btnnine";
            btnnine.Size = new Size(67, 52);
            btnnine.TabIndex = 13;
            btnnine.Text = "9";
            btnnine.UseVisualStyleBackColor = true;
            btnnine.Click += btnnine_Click;
            // 
            // btnclear
            // 
            btnclear.Font = new Font("Wingdings", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnclear.Location = new Point(339, 235);
            btnclear.Name = "btnclear";
            btnclear.Size = new Size(67, 52);
            btnclear.TabIndex = 14;
            btnclear.Text = "";
            btnclear.UseVisualStyleBackColor = true;
            btnclear.Click += button14_Click;
            // 
            // btnactclr
            // 
            btnactclr.Location = new Point(427, 235);
            btnactclr.Name = "btnactclr";
            btnactclr.Size = new Size(67, 52);
            btnactclr.TabIndex = 15;
            btnactclr.Text = "AC";
            btnactclr.UseVisualStyleBackColor = true;
            btnactclr.Click += button15_Click;
            // 
            // btnfour
            // 
            btnfour.Location = new Point(47, 309);
            btnfour.Name = "btnfour";
            btnfour.Size = new Size(67, 52);
            btnfour.TabIndex = 16;
            btnfour.Text = "4";
            btnfour.UseVisualStyleBackColor = true;
            btnfour.Click += button16_Click;
            // 
            // btnfive
            // 
            btnfive.Location = new Point(144, 309);
            btnfive.Name = "btnfive";
            btnfive.Size = new Size(67, 52);
            btnfive.TabIndex = 17;
            btnfive.Text = "5";
            btnfive.UseVisualStyleBackColor = true;
            btnfive.Click += button17_Click;
            // 
            // btnsix
            // 
            btnsix.Location = new Point(243, 309);
            btnsix.Name = "btnsix";
            btnsix.Size = new Size(67, 52);
            btnsix.TabIndex = 18;
            btnsix.Text = "6";
            btnsix.UseVisualStyleBackColor = true;
            btnsix.Click += button18_Click;
            // 
            // btndivide
            // 
            btndivide.Location = new Point(427, 309);
            btndivide.Name = "btndivide";
            btndivide.Size = new Size(67, 52);
            btndivide.TabIndex = 20;
            btndivide.Text = "/";
            btndivide.UseVisualStyleBackColor = true;
            btndivide.Click += button20_Click;
            // 
            // btnone
            // 
            btnone.Location = new Point(47, 377);
            btnone.Name = "btnone";
            btnone.Size = new Size(67, 52);
            btnone.TabIndex = 21;
            btnone.Text = "1";
            btnone.UseVisualStyleBackColor = true;
            btnone.Click += btnone_Click;
            // 
            // btntwo
            // 
            btntwo.Location = new Point(144, 377);
            btntwo.Name = "btntwo";
            btntwo.Size = new Size(67, 52);
            btntwo.TabIndex = 22;
            btntwo.Text = "2";
            btntwo.UseVisualStyleBackColor = true;
            btntwo.Click += btntwo_Click;
            // 
            // btnthree
            // 
            btnthree.Location = new Point(243, 377);
            btnthree.Name = "btnthree";
            btnthree.Size = new Size(67, 52);
            btnthree.TabIndex = 23;
            btnthree.Text = "3";
            btnthree.UseVisualStyleBackColor = true;
            btnthree.Click += btnthree_Click;
            // 
            // btnplus
            // 
            btnplus.Location = new Point(339, 377);
            btnplus.Name = "btnplus";
            btnplus.Size = new Size(67, 52);
            btnplus.TabIndex = 24;
            btnplus.Text = "+";
            btnplus.UseVisualStyleBackColor = true;
            btnplus.Click += btnplus_Click;
            // 
            // btnminus
            // 
            btnminus.Location = new Point(430, 377);
            btnminus.Name = "btnminus";
            btnminus.Size = new Size(67, 52);
            btnminus.TabIndex = 25;
            btnminus.Text = "-";
            btnminus.UseVisualStyleBackColor = true;
            btnminus.Click += btnminus_Click;
            // 
            // btnzero
            // 
            btnzero.Location = new Point(47, 450);
            btnzero.Name = "btnzero";
            btnzero.Size = new Size(67, 52);
            btnzero.TabIndex = 26;
            btnzero.Text = "0";
            btnzero.UseVisualStyleBackColor = true;
            btnzero.Click += btnzero_Click;
            // 
            // btndot
            // 
            btndot.Location = new Point(144, 450);
            btndot.Name = "btndot";
            btndot.Size = new Size(67, 52);
            btndot.TabIndex = 27;
            btndot.Text = ".";
            btndot.UseVisualStyleBackColor = true;
            btndot.Click += btndot_Click;
            // 
            // btnexp
            // 
            btnexp.Location = new Point(243, 453);
            btnexp.Name = "btnexp";
            btnexp.Size = new Size(67, 52);
            btnexp.TabIndex = 28;
            btnexp.Text = "Exp";
            btnexp.UseVisualStyleBackColor = true;
            btnexp.Click += button28_Click;
            // 
            // btnans
            // 
            btnans.Location = new Point(339, 451);
            btnans.Name = "btnans";
            btnans.Size = new Size(67, 52);
            btnans.TabIndex = 29;
            btnans.Text = "Ans";
            btnans.UseVisualStyleBackColor = true;
            // 
            // btnequal
            // 
            btnequal.Location = new Point(430, 450);
            btnequal.Name = "btnequal";
            btnequal.Size = new Size(67, 52);
            btnequal.TabIndex = 30;
            btnequal.Text = "=";
            btnequal.UseVisualStyleBackColor = true;
            btnequal.Click += btnequal_Click;
            // 
            // btnmulty
            // 
            btnmulty.Location = new Point(339, 309);
            btnmulty.Name = "btnmulty";
            btnmulty.Size = new Size(67, 52);
            btnmulty.TabIndex = 19;
            btnmulty.Text = "×";
            btnmulty.UseVisualStyleBackColor = true;
            btnmulty.Click += button19_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(522, 520);
            Controls.Add(btnequal);
            Controls.Add(btnans);
            Controls.Add(btnexp);
            Controls.Add(btndot);
            Controls.Add(btnzero);
            Controls.Add(btnminus);
            Controls.Add(btnplus);
            Controls.Add(btnthree);
            Controls.Add(btntwo);
            Controls.Add(btnone);
            Controls.Add(btndivide);
            Controls.Add(btnmulty);
            Controls.Add(btnsix);
            Controls.Add(btnfive);
            Controls.Add(btnfour);
            Controls.Add(btnactclr);
            Controls.Add(btnclear);
            Controls.Add(btnnine);
            Controls.Add(btneight);
            Controls.Add(btnseven);
            Controls.Add(btnleftbrckt);
            Controls.Add(btnrgtbrckt);
            Controls.Add(btnpercentage);
            Controls.Add(btnsquare);
            Controls.Add(btnshift);
            Controls.Add(btnlog);
            Controls.Add(btnin);
            Controls.Add(btntan);
            Controls.Add(btncos);
            Controls.Add(textresult);
            Controls.Add(btnsin);
            Name = "Form1";
            Text = "Scientific Calculator";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnsin;
        private TextBox textresult;
        private Button btncos;
        private Button btntan;
        private Button btnin;
        private Button btnlog;
        private Button btnshift;
        private Button btnsquare;
        private Button btnpercentage;
        private Button btnrgtbrckt;
        private Button btnleftbrckt;
        private Button btnseven;
        private Button btneight;
        private Button btnnine;
        private Button btnclear;
        private Button btnactclr;
        private Button btnfour;
        private Button btnfive;
        private Button btnsix;
        private Button btndivide;
        private Button btnone;
        private Button btntwo;
        private Button btnthree;
        private Button btnplus;
        private Button btnminus;
        private Button btnzero;
        private Button btndot;
        private Button btnexp;
        private Button btnans;
        private Button btnequal;
        private Button btnmulty;
    }
}